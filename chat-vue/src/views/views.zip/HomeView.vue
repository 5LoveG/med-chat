<template>
  <div class="container">
    <div class="head">聊天</div>

    <div class="aside-main-container">
      <div class="aside">
        <!-- 新对话 -->

        <button class="new-conv" type="primary" @click="createNewSession">
          新对话
        </button>

        <!-- 历史记录列表 -->
        <div class="session-list">
          <div
            v-for="session in chatSessions"
            :key="session.id"
            class="session-item"
            :class="{ 'active-session': session.id === currentSessionId }"
            @click="switchSession(session.id)"
          >
            <span class="session-title">{{ session.title }}</span>
            <button
              type="text"
              class="delete-btn"
              @click.stop="deleteSession(session.id)"
            >
              删除
            </button>
          </div>
        </div>
      </div>

      <div class="main">
        <!-- 聊天消息区域 -->
        <div ref="chatContainer" class="chat">
          <div
            v-for="(msg, index) in currentMessages"
            :key="index"
            class="message-item"
            :class="{ 'user-message': msg.sender === 'user' }"
          >
            <div class="message-bubble">
              <div class="message-content">{{ msg.content }}</div>
            </div>
          </div>
        </div>

        <!-- 输入区域 -->
        <div class="input">
          <input
            class="text"
            v-model="inputMessage"
            placeholder="输入消息..."
            @keyup.enter="sendMessage"
          />
          <button class="submit-btn" @click="sendMessage">提交</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      inputMessage: "",
      chatSessions: [], // 所有聊天会话
      currentSessionId: null, // 当前选中的会话ID
    };
  },
  computed: {
    // 当前会话的消息列表
    currentMessages() {
      const session = this.chatSessions.find(
        (s) => s.id === this.currentSessionId
      );
      return session ? session.messages : [];
    },
  },
  methods: {
    // 创建新会话
    createNewSession() {
      const newSession = {
        id: Date.now(),
        title: `新会话 ${new Date().toLocaleTimeString()}`,
        messages: [],
        createTime: new Date(),
      };
      this.chatSessions.unshift(newSession);
      this.currentSessionId = newSession.id;
    },

    // 切换会话
    switchSession(sessionId) {
      const selectedSession = this.chatSessions.find((s) => s.id === sessionId);
      if (selectedSession) {
        // 从原位置移除该会话
        this.chatSessions = this.chatSessions.filter((s) => s.id !== sessionId);
        // 将该会话放到列表第一项
        this.chatSessions.unshift(selectedSession);
      }
      this.currentSessionId = sessionId;
    },

    // 删除会话
    deleteSession(sessionId) {
      this.chatSessions = this.chatSessions.filter((s) => s.id !== sessionId);
      // 如果删除的是当前会话，自动选择第一个会话
      if (sessionId === this.currentSessionId) {
        this.currentSessionId =
          this.chatSessions.length > 0 ? this.chatSessions[0].id : null;
      }
    },

    scrollToBottom() {
      this.$nextTick(() => {
        const container = this.$refs.chatContainer;
        if (container) {
          container.scrollTop = container.scrollHeight;
        }
      });
    },

    sendMessage() {
      if (!this.inputMessage.trim()) return;

      // 如果没有会话则创建
      if (!this.currentSessionId) {
        this.createNewSession();
      }

      const currentSession = this.chatSessions.find(
        (s) => s.id === this.currentSessionId
      );

      // 如果是第一条消息则更新标题
      if (currentSession.messages.length === 0) {
        currentSession.title =
          this.inputMessage.substring(0, 20) || currentSession.title;
      }

      // 添加用户消息
      currentSession.messages.push({
        content: this.inputMessage,
        sender: "user",
      });

      this.scrollToBottom();
      this.mockBotResponse();
      this.inputMessage = "";
    },

    async mockBotResponse() {
      const botResponse = "收到消息：" + this.inputMessage;

      setTimeout(() => {
        const currentSession = this.chatSessions.find(
          (s) => s.id === this.currentSessionId
        );
        if (currentSession) {
          currentSession.messages.push({
            content: botResponse,
            sender: "bot",
          });
          this.scrollToBottom();
        }
      }, 500);
    },
  },
};
</script>

<style>
html,
body {
  height: 100%;
  margin: 0;
}
.container {
  height: 100%;
  background-color: #020202;
  display: flex;
  flex-direction: column;
}
.head {
  height: 10%;
  display: flex;
  flex-direction: row;
  background-color: #939fc1;
}

.aside-main-container {
  height: 90%;
  display: flex;
  flex-direction: row;
  background-color: #f20d0d;
}

.aside {
  width: 10%;
  display: flex;
  flex-direction: column;
  background-color: #0bd1d1;
}

.main {
  width: 90%;
  background-color: #e1e7f4;
  color: #181717;
}
.new-conv {
  height: 5%;
  cursor: pointer;
}

.session-list {
  height: 95%;
  background: #2076cd;
  overflow-y: auto;
}

.session-item {
  color: #020202;
  height: 5%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
}

.session-item:hover {
  background-color: #dd0707;
}

.active-session {
  background-color: #ddcc33;
  font-weight: bold;
}

.session-title {
  overflow: hidden;
  text-overflow: ellipsis; /*省略号*/
  white-space: nowrap; /*禁止文本自动换行*/
}

.delete-btn {
  padding: 0;
  color: #f56c6c;
  margin-left: 8px;
}

.chat {
  background-color: #0e2d6b;
  height: 90%;
  overflow: auto; /* 聊天内容超出时显示滚动条 */
}

/* 消息项 */
.message-item {
  display: flex;
  margin-bottom: 15px;
}

/* 用户消息靠右 */
.message-item.user-message {
  justify-content: flex-end;
}

/* 消息气泡 */
.message-bubble {
  max-width: 70%;
  padding: 12px 16px;
  border-radius: 15px;
  background: #e4e6eb;
  position: relative;
}

/* 用户消息样式 */
.user-message .message-bubble {
  background: #0084ff;
  color: white;
}

/* 消息内容 */
.message-content {
  font-size: 14px;
  line-height: 1.5;
  word-break: break-word;
  text-align: left; /* 新增：强制所有文本左对齐 */
}

.input {
  height: 10%;
  display: flex;
  flex-direction: row;
  background-color: #972a2a;
}
.text {
  width: 90%;
}
.submit-btn {
  width: 5%;
}
.record-btn {
  width: 5%;
}
</style>