<template>
  <div class="container">
    <button @click="toggleCamera">
      {{ isCameraOpen ? "拍照" : "开启摄像头" }}
    </button>
    <textarea
      v-model="resultText"
      placeholder="识别结果将显示在这里"
    ></textarea>
    <video ref="videoElement" v-show="isCameraOpen" autoplay></video>
    <canvas ref="canvasElement" style="display: none"></canvas>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      isCameraOpen: false,
      resultText: "",
      mediaStream: null,
    };
  },
  methods: {
    async toggleCamera() {
      if (!this.isCameraOpen) {
        try {
          this.mediaStream = await navigator.mediaDevices.getUserMedia({
            video: true,
          });
          this.$refs.videoElement.srcObject = this.mediaStream;
          this.isCameraOpen = true;
        } catch (error) {
          console.error("无法访问摄像头:", error);
          alert("无法访问摄像头，请确保已授予权限");
        }
      } else {
        this.capturePhoto();
        this.isCameraOpen = false;
        this.mediaStream.getTracks().forEach((track) => track.stop());
      }
    },
    capturePhoto() {
      const video = this.$refs.videoElement;
      const canvas = this.$refs.canvasElement;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext("2d").drawImage(video, 0, 0);

      canvas.toBlob(async (blob) => {
        const formData = new FormData();
        formData.append("image", blob, "photo.jpg");

        try {
          const response = await axios.post(
            "http://localhost:5000/picture",
            formData,
            {
              headers: { "Content-Type": "multipart/form-data" },
            }
          );
          this.resultText = response.data.text;
        } catch (error) {
          console.error("识别失败:", error);
          alert("OCR处理失败");
        }
      }, "image/jpeg");
    },
  },
};
</script>

<style>
.container {
  display: flex;
  gap: 20px;
  padding: 20px;
}

button {
  padding: 10px 20px;
  cursor: pointer;
}

textarea {
  width: 300px;
  height: 100px;
  padding: 10px;
}

video {
  width: 400px;
  border: 1px solid #ccc;
}
</style>