<template>
  <div>
    <button @click="toggleRecording">
      {{ isRecording ? "停止录音" : "开始录音" }}
    </button>
    <!-- 新增文本显示区域 -->
    <div style="margin-top: 20px">
      <h3>识别结果：</h3>
      <textarea
        v-model="transcribedText"
        rows="5"
        cols="50"
        placeholder="这里将显示识别后的文字"
        readonly
      ></textarea>
    </div>
    <p v-if="error" style="color: red">{{ error }}</p>
  </div>
</template>

<script setup>
import { ref } from "vue";
import axios from "axios";

const isRecording = ref(false);
const mediaRecorder = ref(null);
const audioChunks = ref([]);
const error = ref(null);
const transcribedText = ref(""); // 新增响应式文本变量

const startRecording = async () => {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder.value = new MediaRecorder(stream);

    mediaRecorder.value.ondataavailable = (e) => {
      audioChunks.value.push(e.data);
    };

    mediaRecorder.value.onstop = async () => {
      const audioBlob = new Blob(audioChunks.value, { type: "audio/wav" });
      const formData = new FormData();
      formData.append("file", audioBlob, "recording.wav");

      try {
        // 修改请求处理
        const response = await axios.post(
          "http://localhost:5000/upload",
          formData,
          {
            headers: { "Content-Type": "multipart/form-data" },
          }
        );

        // 显示识别结果
        if (response.data.text) {
          transcribedText.value = response.data.text;
        }
      } catch (err) {
        error.value = "识别失败：" + (err.response?.data?.error || err.message);
        console.error("上传失败:", err);
      }

      audioChunks.value = [];
      stream.getTracks().forEach((track) => track.stop());
    };

    mediaRecorder.value.start();
    isRecording.value = true;
  } catch (err) {
    error.value = "需要麦克风权限才能录音";
    console.error("录音错误:", err);
  }
};

const toggleRecording = () => {
  if (!isRecording.value) {
    startRecording();
  } else {
    mediaRecorder.value.stop();
    isRecording.value = false;
  }
};
</script>

<style scoped>
textarea {
  width: 300px;
  padding: 10px;
  margin-top: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}
</style>